#-------------------------------------------------------------------------------
# Copyright (c) 2019-2022 University of Newcastle upon Tyne. All rights reserved.
# Copyright (c) 2022-2025 Arjuna Technologies, Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#
# Set up
#

# context("corDS::smk::setup")

set.standard.disclosure.settings()

#
# Tests
#

# context("corDS::smk::pairwise without na")
#test_that("simple corDS, pairwise, full", {
#    x   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
#    y   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
#    use <- 'pairwise.complete'
#
#    res <- corDS("x", "y", use)
#
#    expect_equal(class(res), "list")
#    expect_length(res, 5)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.products), 1)
#        expect_true("matrix" %in% class(res$sums.of.products))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.products), 2)
#        expect_true("matrix" %in% class(res$sums.of.products))
#        expect_true("array" %in% class(res$sums.of.products))
#    }
#    expect_length(res$sums.of.products, 4)
#
#    expect_equal(res$sums.of.products[1], 140.0)
#    expect_equal(res$sums.of.products[2], 140.0)
#    expect_equal(res$sums.of.products[3], 140.0)
#    expect_equal(res$sums.of.products[4], 140.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums), 1)
#        expect_true("matrix" %in% class(res$sums))
#    }
#    else
#    {
#        expect_length(class(res$sums), 2)
#        expect_true("matrix" %in% class(res$sums))
#        expect_true("array" %in% class(res$sums))
#    }
#    expect_length(res$sums, 4)
#
#    expect_equal(res$sums[1], 28.0)
#    expect_equal(res$sums[2], 28.0)
#    expect_equal(res$sums[3], 28.0)
#    expect_equal(res$sums[4], 28.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$complete.counts), 1)
#        expect_true("matrix" %in% class(res$complete.counts))
#    }
#    else
#    {
#        expect_length(class(res$complete.counts), 2)
#        expect_true("matrix" %in% class(res$complete.counts))
#        expect_true("array" %in% class(res$complete.counts))
#    }
#    expect_length(res$complete.counts, 4)
#
#    expect_equal(res$complete.counts[1], 8.0)
#    expect_equal(res$complete.counts[2], 8.0)
#    expect_equal(res$complete.counts[3], 8.0)
#    expect_equal(res$complete.counts[4], 8.0)
#
#    expect_equal(class(res$na.counts), "list")
#    expect_length(res$na.counts, 2)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.squares), 1)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.squares), 2)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#        expect_true("array" %in% class(res$sums.of.squares))
#    }
#    expect_length(res$sums.of.squares, 4)
#
#    expect_equal(res$sums.of.squares[1], 140.0)
#    expect_equal(res$sums.of.squares[2], 140.0)
#    expect_equal(res$sums.of.squares[3], 140.0)
#    expect_equal(res$sums.of.squares[4], 140.0)
#})

#test_that("simple corDS, pairwise, neg. full", {
#    x   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
#    y   <- c(7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0, 0.0)
#    use <- 'pairwise.complete'
#
#    res <- corDS("x", "y", use)
#
#    expect_equal(class(res), "list")
#    expect_length(res, 5)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.products), 1)
#        expect_true("matrix" %in% class(res$sums.of.products))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.products), 2)
#        expect_true("matrix" %in% class(res$sums.of.products))
#        expect_true("array" %in% class(res$sums.of.products))
#    }
#    expect_length(res$sums.of.products, 4)
#
#    expect_equal(res$sums.of.products[1], 140.0)
#    expect_equal(res$sums.of.products[2], 56.0)
#    expect_equal(res$sums.of.products[3], 56.0)
#    expect_equal(res$sums.of.products[4], 140.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums), 1)
#        expect_true("matrix" %in% class(res$sums))
#    }
#    else
#    {
#        expect_length(class(res$sums), 2)
#        expect_true("matrix" %in% class(res$sums))
#        expect_true("array" %in% class(res$sums))
#    }
#    expect_length(res$sums, 4)
#
#    expect_equal(res$sums[1], 28.0)
#    expect_equal(res$sums[2], 28.0)
#    expect_equal(res$sums[3], 28.0)
#    expect_equal(res$sums[4], 28.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$complete.counts), 1)
#        expect_true("matrix" %in% class(res$complete.counts))
#    }
#    else
#    {
#        expect_length(class(res$complete.counts), 2)
#        expect_true("matrix" %in% class(res$complete.counts))
#        expect_true("array" %in% class(res$complete.counts))
#    }
#    expect_length(res$complete.counts, 4)
#
#    expect_equal(res$complete.counts[1], 8.0)
#    expect_equal(res$complete.counts[2], 8.0)
#    expect_equal(res$complete.counts[3], 8.0)
#    expect_equal(res$complete.counts[4], 8.0)
#
#    expect_equal(class(res$na.counts), "list")
#    expect_length(res$na.counts, 2)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.squares), 1)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.squares), 2)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#        expect_true("array" %in% class(res$sums.of.squares))
#    }
#    expect_length(res$sums.of.squares, 4)
#
#    expect_equal(res$sums.of.squares[1], 140.0)
#    expect_equal(res$sums.of.squares[2], 140.0)
#    expect_equal(res$sums.of.squares[3], 140.0)
#    expect_equal(res$sums.of.squares[4], 140.0)
#})

#test_that("simple corDS, pairwise, some", {
#    x   <- c(0.1, 1.0, 1.9, 3.0, 4.0, 5.1, 6.0, 7.0)
#    y   <- c(0.0, 1.2, 2.0, 2.9, 4.0, 5.0, 6.1, 7.0)
#    use <- 'pairwise.complete'
#
#    res <- corDS("x", "y", use)
#
#    expect_equal(class(res), "list")
#    expect_length(res, 5)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.products), 1)
#        expect_true("matrix" %in% class(res$sums.of.products))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.products), 2)
#        expect_true("matrix" %in% class(res$sums.of.products))
#        expect_true("array" %in% class(res$sums.of.products))
#    }
#    expect_length(res$sums.of.products, 4)
#
#    expect_equal(res$sums.of.products[1], 140.63)
#    expect_equal(res$sums.of.products[2], 140.8)
#    expect_equal(res$sums.of.products[3], 140.8)
#    expect_equal(res$sums.of.products[4], 141.06)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums), 1)
#        expect_true("matrix" %in% class(res$sums))
#    }
#    else
#    {
#        expect_length(class(res$sums), 2)
#        expect_true("matrix" %in% class(res$sums))
#        expect_true("array" %in% class(res$sums))
#    }
#
#    expect_length(res$sums, 4)
#
#    expect_equal(res$sums[1], 28.1)
#    expect_equal(res$sums[2], 28.2)
#    expect_equal(res$sums[3], 28.1)
#    expect_equal(res$sums[4], 28.2)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$complete.counts), 1)
#        expect_true("matrix" %in% class(res$complete.counts))
#    }
#    else
#    {
#        expect_length(class(res$complete.counts), 2)
#        expect_true("matrix" %in% class(res$complete.counts))
#        expect_true("array" %in% class(res$complete.counts))
#    }
#    expect_length(res$complete.counts, 4)
#
#    expect_equal(res$complete.counts[1], 8.0)
#    expect_equal(res$complete.counts[2], 8.0)
#    expect_equal(res$complete.counts[3], 8.0)
#    expect_equal(res$complete.counts[4], 8.0)
#
#    expect_equal(class(res$na.counts), "list")
#    expect_length(res$na.counts, 2)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.squares), 1)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.squares), 2)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#        expect_true("array" %in% class(res$sums.of.squares))
#    }
#    expect_length(res$sums.of.squares, 4)
#
#    expect_equal(res$sums.of.squares[1], 140.63)
#    expect_equal(res$sums.of.squares[2], 141.06)
#    expect_equal(res$sums.of.squares[3], 140.63)
#    expect_equal(res$sums.of.squares[4], 141.06)
#})

# context("corDS::smk::pairwise with na")
#test_that("simple corDS, pairwise, some", {
#    x   <- c(0.0, NA, 2.0, 3.0, NA, 5.0, NA, 7.0)
#    y   <- c(0.0, 1.0, NA, 3.0, 4.0, NA, NA, 7.0)
#    use <- 'pairwise.complete'
#
#    res <- corDS("x", "y", use)
#
#    expect_equal(class(res), "list")
#    expect_length(res, 5)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.products), 1)
#        expect_true("matrix" %in% class(res$sums.of.products))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.products), 2)
#        expect_true("matrix" %in% class(res$sums.of.products))
#        expect_true("array" %in% class(res$sums.of.products))
#    }
#    expect_length(res$sums.of.products, 4)
#
#    expect_equal(res$sums.of.products[1], 87.0)
#    expect_equal(res$sums.of.products[2], 58.0)
#    expect_equal(res$sums.of.products[3], 58.0)
#    expect_equal(res$sums.of.products[4], 75.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums), 1)
#        expect_true("matrix" %in% class(res$sums))
#    }
#    else
#    {
#        expect_length(class(res$sums), 2)
#        expect_true("matrix" %in% class(res$sums))
#        expect_true("array" %in% class(res$sums))
#    }
#    expect_length(res$sums, 4)
#
#    expect_equal(res$sums[1], 17.0)
#    expect_equal(res$sums[2], 10.0)
#    expect_equal(res$sums[3], 10.0)
#    expect_equal(res$sums[4], 15.0)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$complete.counts), 1)
#        expect_true("matrix" %in% class(res$complete.counts))
#    }
#    else
#    {
#        expect_length(class(res$complete.counts), 2)
#        expect_true("matrix" %in% class(res$complete.counts))
#        expect_true("array" %in% class(res$complete.counts))
#    }
#    expect_length(res$complete.counts, 4)
#
#    expect_equal(res$complete.counts[1], 5.0)
#    expect_equal(res$complete.counts[2], 3.0)
#    expect_equal(res$complete.counts[3], 3.0)
#    expect_equal(res$complete.counts[4], 5.0)
#
#    expect_equal(class(res$na.counts), "list")
#    expect_length(res$na.counts, 2)
#
#    if (base::getRversion() < '4.0.0')
#    {
#        expect_length(class(res$sums.of.squares), 1)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#    }
#    else
#    {
#        expect_length(class(res$sums.of.squares), 2)
#        expect_true("matrix" %in% class(res$sums.of.squares))
#        expect_true("array" %in% class(res$sums.of.squares))
#    }
#    expect_length(res$sums.of.squares, 4)
#
#    expect_equal(res$sums.of.squares[1], 87.0)
#    expect_equal(res$sums.of.squares[2], 58.0)
#    expect_equal(res$sums.of.squares[3], 58.0)
#    expect_equal(res$sums.of.squares[4], 75.0)
#})

# context("corDS::smk::casewise without na")
test_that("simple corDS, casewise, full", {
    x   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
    y   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
#    use <- 'casewise.complete'

#    res <- corDS("x", "y", use)
    res <- corDS("x", "y")

    expect_equal(class(res), "list")
    expect_length(res, 6)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.products), 1)
        expect_true("matrix" %in% class(res$sums.of.products))
    }
    else
    {
        expect_length(class(res$sums.of.products), 2)
        expect_true("matrix" %in% class(res$sums.of.products))
        expect_true("array" %in% class(res$sums.of.products))
    }
    expect_length(res$sums.of.products, 4)

    expect_equal(res$sums.of.products[1], 140.0)
    expect_equal(res$sums.of.products[2], 140.0)
    expect_equal(res$sums.of.products[3], 140.0)
    expect_equal(res$sums.of.products[4], 140.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums), 1)
        expect_true("matrix" %in% class(res$sums))
    }
    else
    {
        expect_length(class(res$sums), 2)
        expect_true("matrix" %in% class(res$sums))
        expect_true("array" %in% class(res$sums))
    }
    expect_length(res$sums, 4)

    expect_equal(res$sums[1], 28.0)
    expect_equal(res$sums[2], 28.0)
    expect_equal(res$sums[3], 28.0)
    expect_equal(res$sums[4], 28.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$complete.counts), 1)
        expect_true("matrix" %in% class(res$complete.counts))
    }
    else
    {
        expect_length(class(res$complete.counts), 2)
        expect_true("matrix" %in% class(res$complete.counts))
        expect_true("array" %in% class(res$complete.counts))
    }
    expect_length(res$complete.counts, 4)

    expect_equal(res$complete.counts[1], 8.0)
    expect_equal(res$complete.counts[2], 8.0)
    expect_equal(res$complete.counts[3], 8.0)
    expect_equal(res$complete.counts[4], 8.0)

    expect_equal(class(res$na.counts), "list")
    expect_length(res$na.counts, 2)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.squares), 1)
        expect_true("matrix" %in% class(res$sums.of.squares))
    }
    else
    {
        expect_length(class(res$sums.of.squares), 2)
        expect_true("matrix" %in% class(res$sums.of.squares))
        expect_true("array" %in% class(res$sums.of.squares))
    }
    expect_length(res$sums.of.squares, 4)

    expect_equal(res$sums.of.squares[1], 140.0)
    expect_equal(res$sums.of.squares[2], 140.0)
    expect_equal(res$sums.of.squares[3], 140.0)
    expect_equal(res$sums.of.squares[4], 140.0)
})

test_that("simple corDS, casewise, neg. full", {
    x   <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
    y   <- c(7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0, 0.0)
#    use <- 'casewise.complete'

#    res <- corDS("x", "y", use)
    res <- corDS("x", "y")

    expect_equal(class(res), "list")
    expect_length(res, 6)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.products), 1)
        expect_true("matrix" %in% class(res$sums.of.products))
    }
    else
    {
        expect_length(class(res$sums.of.products), 2)
        expect_true("matrix" %in% class(res$sums.of.products))
        expect_true("array" %in% class(res$sums.of.products))
    }
    expect_length(res$sums.of.products, 4)

    expect_equal(res$sums.of.products[1], 140.0)
    expect_equal(res$sums.of.products[2], 56.0)
    expect_equal(res$sums.of.products[3], 56.0)
    expect_equal(res$sums.of.products[4], 140.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums), 1)
        expect_true("matrix" %in% class(res$sums))
    }
    else
    {
        expect_length(class(res$sums), 2)
        expect_true("matrix" %in% class(res$sums))
        expect_true("array" %in% class(res$sums))
    }
    expect_length(res$sums, 4)

    expect_equal(res$sums[1], 28.0)
    expect_equal(res$sums[2], 28.0)
    expect_equal(res$sums[3], 28.0)
    expect_equal(res$sums[4], 28.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$complete.counts), 1)
        expect_true("matrix" %in% class(res$complete.counts))
    }
    else
    {
        expect_length(class(res$complete.counts), 2)
        expect_true("matrix" %in% class(res$complete.counts))
        expect_true("array" %in% class(res$complete.counts))
    }
    expect_length(res$complete.counts, 4)

    expect_equal(res$complete.counts[1], 8.0)
    expect_equal(res$complete.counts[2], 8.0)
    expect_equal(res$complete.counts[3], 8.0)
    expect_equal(res$complete.counts[4], 8.0)

    expect_equal(class(res$na.counts), "list")
    expect_length(res$na.counts, 2)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.squares), 1)
        expect_true("matrix" %in% class(res$sums.of.squares))
    }
    else
    {
        expect_length(class(res$sums.of.squares), 2)
        expect_true("matrix" %in% class(res$sums.of.squares))
        expect_true("array" %in% class(res$sums.of.squares))
    }
    expect_length(res$sums.of.squares, 4)

    expect_equal(res$sums.of.squares[1], 140.0)
    expect_equal(res$sums.of.squares[2], 140.0)
    expect_equal(res$sums.of.squares[3], 140.0)
    expect_equal(res$sums.of.squares[4], 140.0)
})

test_that("simple corDS, casewise, some", {
    x   <- c(0.1, 1.0, 1.9, 3.0, 4.0, 5.1, 6.0, 7.0)
    y   <- c(0.0, 1.2, 2.0, 2.9, 4.0, 5.0, 6.1, 7.0)
#    use <- 'casewise.complete'

#    res <- corDS("x", "y", use)
    res <- corDS("x", "y")

    expect_equal(class(res), "list")
    expect_length(res, 6)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.products), 1)
        expect_true("matrix" %in% class(res$sums.of.products))
    }
    else
    {
        expect_length(class(res$sums.of.products), 2)
        expect_true("matrix" %in% class(res$sums.of.products))
        expect_true("array" %in% class(res$sums.of.products))
    }
    expect_length(res$sums.of.products, 4)

    expect_equal(res$sums.of.products[1], 140.63)
    expect_equal(res$sums.of.products[2], 140.8)
    expect_equal(res$sums.of.products[3], 140.8)
    expect_equal(res$sums.of.products[4], 141.06)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums), 1)
        expect_true("matrix" %in% class(res$sums))
    }
    else
    {
        expect_length(class(res$sums), 2)
        expect_true("matrix" %in% class(res$sums))
        expect_true("array" %in% class(res$sums))
    }
    expect_length(res$sums, 4)

    expect_equal(res$sums[1], 28.1)
    expect_equal(res$sums[2], 28.2)
    expect_equal(res$sums[3], 28.1)
    expect_equal(res$sums[4], 28.2)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$complete.counts), 1)
        expect_true("matrix" %in% class(res$complete.counts))
    }
    else
    {
        expect_length(class(res$complete.counts), 2)
        expect_true("matrix" %in% class(res$complete.counts))
        expect_true("array" %in% class(res$complete.counts))
    }
    expect_length(res$complete.counts, 4)

    expect_equal(res$complete.counts[1], 8.0)
    expect_equal(res$complete.counts[2], 8.0)
    expect_equal(res$complete.counts[3], 8.0)
    expect_equal(res$complete.counts[4], 8.0)

    expect_equal(class(res$na.counts), "list")
    expect_length(res$na.counts, 2)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.squares), 1)
        expect_true("matrix" %in% class(res$sums.of.squares))
    }
    else
    {
        expect_length(class(res$sums.of.squares), 2)
        expect_true("matrix" %in% class(res$sums.of.squares))
        expect_true("array" %in% class(res$sums.of.squares))
    }
    expect_length(res$sums.of.squares, 4)

    expect_equal(res$sums.of.squares[1], 140.63)
    expect_equal(res$sums.of.squares[2], 141.06)
    expect_equal(res$sums.of.squares[3], 140.63)
    expect_equal(res$sums.of.squares[4], 141.06)
})

# context("corDS::smk::casewise with na")
test_that("simple corDS, casewise, some", {
    x   <- c(0.0, NA, 2.0, 3.0, NA, 5.0, NA, 7.0)
    y   <- c(0.0, 1.0, NA, 3.0, 4.0, NA, NA, 7.0)
#    use <- 'casewise.complete'

#    res <- corDS("x", "y", use)
    res <- corDS("x", "y")

    expect_equal(class(res), "list")
    expect_length(res, 6)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.products), 1)
        expect_true("matrix" %in% class(res$sums.of.products))
    }
    else
    {
        expect_length(class(res$sums.of.products), 2)
        expect_true("matrix" %in% class(res$sums.of.products))
        expect_true("array" %in% class(res$sums.of.products))
    }
    expect_length(res$sums.of.products, 4)

    expect_equal(res$sums.of.products[1], 58.0)
    expect_equal(res$sums.of.products[2], 58.0)
    expect_equal(res$sums.of.products[3], 58.0)
    expect_equal(res$sums.of.products[4], 58.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums), 1)
        expect_true("matrix" %in% class(res$sums))
    }
    else
    {
        expect_length(class(res$sums), 2)
        expect_true("matrix" %in% class(res$sums))
        expect_true("array" %in% class(res$sums))
    }
    expect_length(res$sums, 4)

    expect_equal(res$sums[1], 10.0)
    expect_equal(res$sums[2], 10.0)
    expect_equal(res$sums[3], 10.0)
    expect_equal(res$sums[4], 10.0)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$complete.counts), 1)
        expect_true("matrix" %in% class(res$complete.counts))
    }
    else
    {
        expect_length(class(res$complete.counts), 2)
        expect_true("matrix" %in% class(res$complete.counts))
        expect_true("array" %in% class(res$complete.counts))
    }
    expect_length(res$complete.counts, 4)

    expect_equal(res$complete.counts[1], 3.0)
    expect_equal(res$complete.counts[2], 3.0)
    expect_equal(res$complete.counts[3], 3.0)
    expect_equal(res$complete.counts[4], 3.0)

    expect_equal(class(res$na.counts), "list")
    expect_length(res$na.counts, 2)

    if (base::getRversion() < '4.0.0')
    {
        expect_length(class(res$sums.of.squares), 1)
        expect_true("matrix" %in% class(res$sums.of.squares))
    }
    else
    {
        expect_length(class(res$sums.of.squares), 2)
        expect_true("matrix" %in% class(res$sums.of.squares))
        expect_true("array" %in% class(res$sums.of.squares))
    }
    expect_length(res$sums.of.squares, 4)

    expect_equal(res$sums.of.squares[1], 58.0)
    expect_equal(res$sums.of.squares[2], 58.0)
    expect_equal(res$sums.of.squares[3], 58.0)
    expect_equal(res$sums.of.squares[4], 58.0)
})

test_that("corDS throws error when object does not exist", {
    expect_error(corDS("nonexistent_x", "nonexistent_y"), regexp = "does not exist")
})

test_that("corDS throws error when object is of invalid type", {
    bad_input <- list(a = 1:3, b = 4:6)
    y <- c(1.0, 2.0, 3.0)
    expect_error(corDS("bad_input", "y"), regexp = "must be of type")
})

test_that("corDS ignores y when x is a data.frame", {
    input <- data.frame(v1 = c(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0),
                        v2 = c(2.0, 1.0, 4.0, 3.0, 6.0, 5.0, 8.0, 7.0, 10.0, 9.0))
    other <- c(10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0)

    res.x  <- corDS("input", NULL)
    res.xy <- corDS("input", "other")

    expect_equal(res.xy, res.x)
})

test_that("corDS gives the same result for integer input as for numeric", {
    x.numeric <- c(0.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 4.0)
    y.numeric <- c(4.0, 3.0, 3.0, 1.0, 2.0, 0.0, 2.0, 1.0, 1.0)
    x.integer <- as.integer(x.numeric)
    y.integer <- as.integer(y.numeric)

    res.numeric <- corDS("x.numeric", "y.numeric")
    res.integer <- corDS("x.integer", "y.integer")

    expect_equal(res.integer$class, "integer")
    expect_equal(res.integer[names(res.integer) != "class"], res.numeric[names(res.numeric) != "class"])
})

test_that("corDS gives the same result for a matrix as for a data.frame", {
    input.df <- data.frame(v1 = c(0.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 4.0),
                           v2 = c(4.0, 3.0, 3.0, 1.0, 2.0, 0.0, 2.0, 1.0, 1.0))
    input.matrix <- as.matrix(input.df)

    res.df <- corDS("input.df")
    res.matrix <- corDS("input.matrix")

    expect_true("matrix" %in% res.matrix$class)
    expect_equal(res.matrix[names(res.matrix) != "class"], res.df[names(res.df) != "class"])
})

test_that("corDS accepts a factor x, correlating on its level codes", {
    fvar <- factor(c("m", "f", "m", "f", "m", "f", "m", "f", "m", "f"))
    yvar <- c(1.0, 5.0, 2.0, 6.0, 3.0, 7.0, 2.0, 8.0, 1.0, 9.0)

    res <- corDS("fvar", "yvar")

    expect_equal(res$class, "factor")
    expect_equal(res$sums[1, 2], sum(as.integer(fvar)))
})

#
# Done
#

# context("corDS::smk::shutdown")

# context("corDS::smk::done")
