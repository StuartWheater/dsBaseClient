#-------------------------------------------------------------------------------
# Copyright (c) 2019-2022 University of Newcastle upon Tyne. All rights reserved.
# Copyright (c) 2022-2025 Arjuna Technologies, Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#
# Set up
#

# context("varDS::smk::setup")

set.standard.disclosure.settings()

#
# Tests
#

# context("varDS::smk::numeric")
test_that("numeric varDS", {
    input <- c(0.0, 1.0, 2.0, 3.0, 4.0)

    res <- varDS("input")

    expect_length(res, 6)
    expect_equal(class(res), "list")
    expect_equal(class(res$Sum), "numeric")
    expect_equal(res$Sum, 10.0)
    expect_equal(class(res$SumOfSquares), "numeric")
    expect_equal(res$SumOfSquares, 30.0)
    expect_equal(class(res$Nmissing), "integer")
    expect_equal(res$Nmissing, 0)
    expect_equal(class(res$Nvalid), "integer")
    expect_equal(res$Nvalid, 5)
    expect_equal(class(res$Ntotal), "integer")
    expect_equal(res$Ntotal, 5)
    expect_equal(res$class, "numeric")
})

# context("varDS::smk::numeric with NA")
test_that("numeric varDS, with NA", {
    input <- c(0.0, NA, 2.0, NA, 4.0)

    res <- varDS("input")

    expect_length(res, 6)
    expect_equal(class(res), "list")
    expect_equal(class(res$Sum), "numeric")
    expect_equal(res$Sum, 6.0)
    expect_equal(class(res$SumOfSquares), "numeric")
    expect_equal(res$SumOfSquares, 20.0)
    expect_equal(class(res$Nmissing), "integer")
    expect_equal(res$Nmissing, 2)
    expect_equal(class(res$Nvalid), "integer")
    expect_equal(res$Nvalid, 3)
    expect_equal(class(res$Ntotal), "integer")
    expect_equal(res$Ntotal, 5)
    expect_equal(res$class, "numeric")
})

# context("varDS::smk::numeric with all NA")
test_that("numeric varDS, with all NA", {
    input <- rep(NA_real_, 5)

    res <- varDS("input")

    expect_length(res, 6)
    expect_equal(class(res), "list")
    expect_equal(class(res$Sum), "numeric")
    expect_equal(res$Sum, 0)
    expect_equal(class(res$SumOfSquares), "numeric")
    expect_equal(res$SumOfSquares, 0)
    expect_equal(class(res$Nmissing), "integer")
    expect_equal(res$Nmissing, 5)
    expect_equal(class(res$Nvalid), "integer")
    expect_equal(res$Nvalid, 0)
    expect_equal(class(res$Ntotal), "integer")
    expect_equal(res$Ntotal, 5)
    expect_equal(res$class, "numeric")
})

# context("varDS::smk::logical with all NA")
test_that("logical varDS, with all NA", {
    input <- c(NA, NA, NA, NA, NA)

    res <- varDS("input")

    expect_equal(class(res$Sum), "integer")
    expect_equal(res$Sum, 0)
    expect_equal(res$SumOfSquares, 0)
    expect_equal(res$Nmissing, 5)
    expect_equal(res$Nvalid, 0)
    expect_equal(res$Ntotal, 5)
    expect_equal(res$class, "logical")
})

test_that("varDS throws error when object does not exist", {
    expect_error(varDS("nonexistent_object"), regexp = "does not exist")
})

test_that("varDS throws error when object is not numeric or integer", {
    bad_input <- c("a", "b", "c")
    expect_error(varDS("bad_input"), regexp = "must be of type numeric, integer or logical")
})

test_that("varDS gives the same result for integer input as for numeric", {
    input.numeric <- c(0.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 4.0)
    input.integer <- as.integer(input.numeric)

    res.numeric <- varDS("input.numeric")
    res.integer <- varDS("input.integer")

    expect_equal(res.integer$class, "integer")
    expect_equal(res.integer[names(res.integer) != "class"], res.numeric[names(res.numeric) != "class"])
})

#
# Done
#

# context("varDS::smk::shutdown")

# context("varDS::smk::done")
